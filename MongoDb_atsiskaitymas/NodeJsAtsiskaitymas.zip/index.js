const express = require("express");
const { MongoClient, ObjectId } = require("mongodb");

const app = express();
require("dotenv").config();

const URI = process.env.URI;
const client = new MongoClient(URI);
const PORT = +process.env.PORT || 5001;

const DB = process.env.DB;
const DBCOLLECTION = process.env.DBCOLLECTION;
const DBCOLLECTION1 = process.env.DBCOLLECTION1;

app.use(express.json());

app.get("/users", async (_, res) => {

  try {
    const connection = await client.connect();
  
    const namesList = await connection
      .db(DB)
      .collection(DBCOLLECTION)
      .find()
      .toArray();

    await connection.close();

    res.send({ namesList }).end();
  } catch (err) {
    res.status(500).send({ err }).end();
    throw Error(err);
  }
});

app.get("/userorders", async (req, res) => {
  const filterName = req.body.name;
 
    const pipeline = [
      {
        $match: {
          _id: ObjectId(user.id)
        },
      },
      {
        $group: {
          name: user.name,
          totalPrice: { $sum: "$price" },
        },
      },
      {
        $sort: {
          name: 1,
        },
      },
    ];
  
    try {
      const docs = [];
      const con = await client.connect();
      const db = con.db(DB);
      const user = await db.collection(DBCOLLECTION1).findOne({ name: filterName });
      const orders = db.collection(DBCOLLECTION);
  
      const prices = await orders.filter("_id").toArray();
  
      // pasikartojantys atvejai paliekami
      // const foundPrices = await collection.find({ price: 14 })
      // console.log({ foundPrices });
  
      const availableProductsCount = await collection.count({
        isAvailable: false,
      });
  
      const aggregationCursor = collection.aggregate(pipeline);
  
      for await (const doc of aggregationCursor) {
        docs.push(doc);
      }
  
      await con.close();
  
      res.send({ prices, availableProductsCount }).end();
    } catch (error) {
      res.status(500).send({ error }).end();
      throw Error(error);
    }
  });

app.listen(PORT, () => console.log(`server is running on port: ${PORT
}`));